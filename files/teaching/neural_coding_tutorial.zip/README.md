# Neural Coding Tutorial, by Jorge A. Menendez

This zip file should include in it the following files:

* `neural_coding_tutorial.ipynb`: a Jupyter notebook with exercises covering Population Vector decoding, Optimal Linear Estimator, Maximum Likelihood decoding, Fisher Information, and noise correlations
* `neural_coding_tutorial_solns.ipynb`: my solutions to these exercises
* `requirements.txt`: text file with Python packages and versions needed to run the above notebooks (these can be downloaded using `pip3 install -r requirements.txt`)
