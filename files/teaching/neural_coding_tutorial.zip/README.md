# Neural Coding Tutorial
### by Jorge A. Menendez

This zip file should include in it the following files:

* `neural_coding_tutorial.ipynb`: a Jupyter notebook with exercises covering Population Vector decoding, Optimal Linear Estimator, Maximum Likelihood decoding, Fisher Information, and noise correlations
* `neural_coding_tutorial_solns.ipynb`: my solutions to these exercises
* `environment.yml`: text file with the package versions used to write and run these notebooks

The required packages can be easily installed in a `conda` virtual environment named `tutorial` using
```
conda env create --name tutorial --file environment.yml
```
Alternatively, you can try installing these packages manually. The packages required for this tutorial are:
```
jupyter
numpy
matplotlib
scipy
```
See the `environment.yml` file for the particular versions used in writing this tutorial.





