import numpy as np
from numpy import random as rd
import matplotlib.pyplot as plt


def epsilon_greedy(action_values, epsilon=0.1):
    if len(np.unique(action_values)) == 1:
        return rd.choice(len(action_values))
    else:
        if rd.rand() < epsilon:
            return rd.choice(len(action_values))
        else:
            return np.argmax(action_values)


class maze_task():
    """
    Maze task, based on "Quentin's world" environment, taken from old CCNSS tutorial code
    100 states (10-by-10 grid world).
    The mapping from state to the grid is as follows:
    90 ...       99
    ...
    40 ...       49
    30 ...       39
    20 21 22 ... 29
    10 11 12 ... 19
    0  1  2  ...  9
    54 is the start state.
    Actions 0, 1, 2, 3 correspond to right, up, left, down.
    Moving to a location in the wall or towards border when already at the border 
        will result in a state transition to the same location.
    Each state transition induces a reward of -1.
    Except at goal state (99), where a reward of 100 is delivered and 
        the episode terminated.
    """

    def __init__(self, wall=False):
        self.name = "The Maze of Death"
        self.n_states = 100
        self.n_actions = 4
        self.dim_x = 10
        self.dim_y = 10
        self.init_state = 54
        self.goal_state = 99
        self.goal_reward = 100

        if wall:
            # Define maze wall parameters
            wall_start_horizontal = 2
            wall_start_vertical = 2
            wall_width = 3
            wall_height = 6

            # Left wall
            start = wall_start_vertical * 10 + wall_start_horizontal
            end = (wall_start_vertical + wall_height) * 10
            left_wall = np.arange(start, end, 10)

            # Right wall
            start = wall_start_vertical * 10 + wall_start_horizontal + wall_width + 1
            end = (wall_start_vertical + wall_height) * 10
            right_wall = np.arange(start, end, 10)

            # Upper wall
            start = (wall_start_vertical + wall_height - 1) * 10 + wall_start_horizontal
            end = start + wall_width + 1
            upper_wall = np.arange(start, end, 1)

            # Lower wall
            end = wall_start_vertical * 10 + wall_start_horizontal + wall_width + 1
            start = end - 2
            lower_wall = np.arange(start, end, 1)

            # Generate list with states on the wall
            self.walls = np.unique(np.concatenate([right_wall, left_wall, upper_wall, lower_wall]))
        else:
            self.walls = []

    def get_outcome(self, state, action):

        # State transition: terminate episode at goal state
        if state == self.goal_state:
            next_state = None

        # State transition: move right
        elif action == 0:
            next_state = state + 1
            # Check if you're on the border
            if state % 10 == 9:  # right border
                next_state = state

        # State transition: move up
        elif action == 1:
            next_state = state + 10
            # Check if you're on the border
            if state >= 90:  # top border
                next_state = state

        # State transition: move left
        elif action == 2:
            next_state = state - 1
            # Check if you're on the border
            if state % 10 == 0:  # left border
                next_state = state

        # State transition: move down
        elif action == 3:
            next_state = state - 10
            # Check if you're on the border
            if state <= 9:  # bottom border
                next_state = state

        # Inexistent action
        else:
            print("Action must be between 0 and 3.")
            next_state = None
            reward = None

        # State transition: can't move through walls
        if next_state in self.walls:
            next_state = state

        # Reward
        if state == self.goal_state:
            reward = self.goal_reward
        else:
            reward = -1

        return int(next_state) if next_state is not None else None, reward

    def get_states(self):
        """
        Return list of states
        """
        return np.arange(self.n_states)

    def get_actions(self, index=None, rep='index'):
        """
        Return list of states
        """
        if rep is 'index':
            # Index representation
            action_rep = np.arange(self.n_actions)
        elif rep is 'label':
            # Letter label representation
            action_rep = ['R', 'U', 'L', 'D']
        elif rep is 'coord':
            # Coordinate representation
            action_rep = [np.array([1, 0]), np.array([0, 1]), np.array([-1, 0]), np.array([0, -1])]
        elif rep is 'tabular':
            # Tabular representation
            action_rep = []
            for action in range(env.n_actions):
                temp = np.zeros(self.n_actions)
                temp[action] = 1
                action_rep.append(temp)
        if index is None:
            return action_rep
        else:
            return action_rep[index]

    def tabular_rep(self, state):
        """
        Return tabular representation of state, as in Schultz, Dayan, Montague '97
        """
        r = np.zeros(self.n_states)
        r[state] = 1
        return r

    def coord_rep(self, state):
        """
        Return coordinate representation of state
        """
        return np.array([np.remainder(state, 10), 9 - np.floor(state / 10)])

    def simulate_trajectory(self, Q, tsteps=20, epsilon=0.1):
        """
        Simulate trajectories under epsilon greedy policy using given matrix of Q-values
        Arguments:
            Q: n_actions x n_states matrix of Q-values
            tsteps: max number of timesteps for which to simulate trajectories
            epsilon: lapse parameter for epsilon-greedy policy
        """
        state = self.init_state
        traj = [self.coord_rep(state)]
        actions = []
        rewards = []
        for t in range(tsteps):
            action = epsilon_greedy(Q[:, state], epsilon=epsilon)
            next_state, reward = self.get_outcome(state, action)
            if next_state is not None:
                traj.append(self.coord_rep(next_state))
            actions.append(action)
            rewards.append(reward)
            if next_state is None:
                break
            else:
                state = next_state
        return np.array(traj).T, np.array(actions), np.array(rewards)

    def illustrate(self, ax):
        """
        Illustrate the maze map
        """

        # Build matrix with maze features
        maze_map = np.zeros(self.dim_x * self.dim_y)
        for state in range(self.n_states):
            if state in self.walls:
                maze_map[state] = -1
            if state == self.goal_state:
                maze_map[state] = 1

        # Plot
        cmap = plt.cm.get_cmap('bwr', 3)
        cax = ax.imshow(np.flipud(np.reshape(maze_map, (self.dim_x, self.dim_y))), cmap=cmap, vmin=-1.5, vmax=1.5)
        init = self.coord_rep(self.init_state)
        ax.plot(init[0], init[1], 'kx')  # mark initial condition

        # Formatting
        ax.set_title(self.name)
        ax.set_aspect('equal')
        ax.set_xticks(np.arange(self.dim_x) + 0.5)
        ax.set_yticks(np.arange(self.dim_y) + 0.5)
        ax.set_xticklabels([])
        ax.set_yticklabels([])
        ax.tick_params(length=0)
        ax.grid(color='k', linestyle='-', linewidth=1)


class classical_conditioning():
    """
    Classical (Pavlovian) conditioning environment
    States run from 0 to n_steps, corresponding to each timestep in the trial
    CS shown at cs_time, reward delivery reward_delay timesteps later
    Tabular representation returned by tabular_rep() assigns 0s to all timesteps
        before CS presentation, as in Schultz, Dayan, Montague '97
    """

    def __init__(self, n_steps=40, reward_magnitude=10, cs_time=10, reward_delay=10):

        # Task variables
        self.n_steps = n_steps
        self.cs_time = cs_time

        # Reward variables
        self.reward_magnitude = reward_magnitude
        self.reward_time = self.cs_time + reward_delay

        # Environment variables
        self.init_state = 0
        self.n_states = n_steps

    def get_outcome(self, current_state):
        """
        Determine next state and reward
        """

        # Update state
        if current_state < self.n_steps - 1:
            next_state = current_state + 1
        else:
            next_state = None

        # Check for reward
        if current_state == self.reward_time:
            reward = self.reward_magnitude
        else:
            reward = 0

        return next_state, reward

    def get_states(self):
        """
        Return list of states
        """
        return np.arange(self.n_steps)

    def tabular_rep(self, state):
        """
        Return tabular representation of state, as in Schultz, Dayan, Montague '97
        """
        r = np.zeros(self.n_steps)
        if state >= self.cs_time:
            r[state] = 1
        return r

    def illustrate(self, ax):
        """
        Illustrate the timecourse of the stimuli
        """
        arrow_pos = 0.3

        # Time axis
        time_color = 'b'
        linewidth = 4
        ax.plot([0, 0], [arrow_pos / 2, - arrow_pos / 2], color=time_color, lw=linewidth)
        ax.plot([self.n_steps, self.n_steps], [arrow_pos / 2, - arrow_pos / 2], color=time_color, lw=linewidth)
        ax.spines['bottom'].set_position(('data', 0))
        ax.spines['bottom'].set_color(time_color)
        ax.spines['bottom'].set_linewidth(linewidth / 2)
        ax.set_xlabel('timesteps')

        # Conditioned Stimulus
        ax.quiver(self.cs_time, arrow_pos, 0, -arrow_pos, angles='xy', scale_units='xy', scale=1)
        ax.text(self.cs_time, arrow_pos * 1.2, 'CS', horizontalalignment='center', fontsize=12)

        # Rewards
        ax.quiver(self.reward_time, arrow_pos, 0, -arrow_pos, angles='xy', scale_units='xy', scale=1)
        ax.text(self.reward_time, arrow_pos * 1.2, 'reward', horizontalalignment='center', fontsize=12)

        # Formatting
        ax.spines['top'].set_visible(False)
        ax.spines['left'].set_visible(False)
        ax.spines['right'].set_visible(False)
        ax.set_xlim([self.init_state, self.n_steps])
        ax.set_ylim([-1.0, 1.0])
        ax.set_yticks([])
        ax.set_title('Pavlovian Conditioning Trial Structure')


# class classical_conditioning():

#     def __init__(self, n_steps):

#         # Task variables
#         self.n_steps = n_steps
#         self.n_actions = 0

#         # Reward variables
#         self.reward_state = [0,0]
#         self.reward_magnitude = reward_magnitude
#         self.reward_probability = reward_probability
#         self.reward_time = reward_time

#         # Time step at which the conditioned stimulus is presented
#         self.cs_time = int(n_steps/4) - 1

#         # Create a state dictionary
#         self.create_state_dictionary()

#     def define_reward(self, reward_magnitude, reward_time):

#         """
#         Determine reward state and magnitude of reward
#         """
#         if reward_time >= self.n_steps - self.cs_time:
#             self.reward_magnitude = 0

#         else:
#             self.reward_magnitude = reward_magnitude
#             self.reward_state = [1, reward_time]

#     def get_outcome(self, current_state, action = 0):

#         """
#         Determine next state and reward
#         """
#         # Update state
#         if current_state < self.n_steps - 1:
#             next_state = current_state + 1
#         else:
#             next_state = 0

#         # Check for reward
#         if self.reward_state == self.state_dict[current_state]:
#             reward = self.reward_magnitude
#         else:
#             reward = 0

#         return next_state, reward

#     def create_state_dictionary(self):

#         """
#         This dictionary maps number of time steps/ state identities
#         in each episode to some useful state attributes:

#         state      - 0 1 2 3 4 5 (cs) 6 7 8 9 10 11 12 ...
#         is_delay   - 0 0 0 0 0 0 (cs) 1 1 1 1  1  1  1 ...
#         t_in_delay - 0 0 0 0 0 0 (cs) 1 2 3 4  5  6  7 ...
#         """
#         d = 0

#         self.state_dict = {}
#         for s in range(self.n_steps):
#             if s <= self.cs_time:
#                 self.state_dict[s] = [0,0]
#             else:
#                 d += 1 # Time in delay
#                 self.state_dict[s] = [1,d]
#
