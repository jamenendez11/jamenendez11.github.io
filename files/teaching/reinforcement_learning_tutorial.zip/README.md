# Reinforcement Learning Tutorial
### by Jorge A. Menendez

This zip file should include in it the following files:

* `RL_tutorial.ipynb`: a Jupyter notebook with exercises covering Rescorla-Wagner, TD learning, SARSA, and Q-learning
* `RL_tutorial_solns.ipynb`: my solutions to these exercises
* `RL_tutorial_fns.py`: script with RL environment functions used in the above notebooks
* some `.png` files with images embedded in the notebooks
* `environment.yml`: text file with the package versions used to write and run these notebooks

The required packages can be easily installed in a `conda` virtual environment named `tutorial` using
```
conda env create --name tutorial --file environment.yml
```
Alternatively, you can try installing these packages manually. The packages required for this tutorial are:
```
jupyter
numpy
matplotlib
```
See the `environment.yml` file for the particular versions used in writing this tutorial.


