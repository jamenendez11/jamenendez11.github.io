# Reinforcement Learning Tutorial, by Jorge A. Menendez

This zip file should include in it the following files:

* `RL_tutorial.ipynb`: a Jupyter notebook with exercises covering Rescorla-Wagner, TD learning, SARSA, and Q-learning
* `RL_tutorial_solns.ipynb`: my solutions to these exercises
* `RL_tutorial_fns.py`: script with RL environment functions used in the above notebooks
* `requirements.txt`: text file with Python packages and versions needed to run the above notebooks (these can be downloaded using `pip3 install -r requirements.txt`)
* some `.png` files with images embedded in the notebooks
