# Deep Learning Tutorial
### by Jorge A. Menendez

This zip file should include in it the following files:

* `DL_tutorial_part1_SGD.ipynb`: a Jupyter notebook with exercises covering stochastic gradient descent, logistic regression, automatic differentiation, and stochastic gradient descent with PyTorch
* `DL_tutorial_part1_SGD_solns.ipynb`: my solutions to these exercises
* `DL_tutorial_part2_FFnets.ipynb`: a Jupyter notebook with exercises covering building and training fully connected deep networks with PyTorch
* `DL_tutorial_part3_rnns.ipynb`: a Jupyter notebook with exercises covering building and training recurrent neural networks with PyTorch
* some `.png` files with images embedded in the notebooks
* `environment.yml`: text file with the package versions used to write and run these notebooks

The required packages can be easily installed in a `conda` virtual environment named `tutorial` using
```
conda env create --name tutorial --file environment.yml
```
Alternatively, you can try installing these packages manually. The packages required for this tutorial are:
```
jupyter
numpy
pytorch
torchvision
matplotlib
scikit-learn
```
See the `environment.yml` file for the particular versions used in writing this tutorial.


