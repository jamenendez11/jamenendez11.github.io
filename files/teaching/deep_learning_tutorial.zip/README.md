# Deep Learning Tutorial, by Jorge A. Menendez

This zip file should include in it the following files:

* `DL_tutorial_part1_SGD.ipynb`: a Jupyter notebook with exercises covering stochastic gradient descent, logistic regression, automatic differentiation, and stochastic gradient descent with PyTorch
* `DL_tutorial_part1_SGD_solns.ipynb`: my solutions to these exercises
* `DL_tutorial_part2_FFnets.ipynb`: a Jupyter notebook with exercises covering building and training fully connected deep networks with PyTorch
* `DL_tutorial_part3_rnns.ipynb`: a Jupyter notebook with exercises covering building and training recurrent neural networks with PyTorch
* `requirements.txt`: text file with Python packages and versions needed to run the above notebooks (these can be downloaded using `pip3 install -r requirements.txt`)
* some `.png` files with images embedded in the notebooks
